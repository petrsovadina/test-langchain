from collections import namedtuple
import altair as alt
import math
import pandas as pd
import streamlit as st

"""
# Welcome to Streamlit!

Edit `/streamlit_app.py` to customize this app to your heart's desire :heart:

If you have any questions, checkout our [documentation](https://docs.streamlit.io) and [community
forums](https://discuss.streamlit.io).

In the meantime, below is an example of what you can do with just a few lines of code:
"""


with st.echo(code_location='below'):
    total_points = st.slider("Number of points in spiral", 1, 5000, 2000)
    num_turns = st.slider("Number of turns in spiral", 1, 100, 9)

    Point = namedtuple('Point', 'x y')
    data = []

    points_per_turn = total_points / num_turns

    for curr_point_num in range(total_points):
        curr_turn, i = divmod(curr_point_num, points_per_turn)
        angle = (curr_turn + 1) * 2 * math.pi * i / points_per_turn
        radius = curr_point_num / total_points
        x = radius * math.cos(angle)
        y = radius * math.sin(angle)
        data.append(Point(x, y))

    st.altair_chart(alt.Chart(pd.DataFrame(data), height=500, width=500)
        .mark_circle(color='#0068c9', opacity=0.5)
        .encode(x='x:Q', y='y:Q'))

import requests

BASE_API_URL = "https://langflow-personal.up.railway.app/api/v1/process"
FLOW_ID = "345acd8c-b3e1-455d-bd95-59aea84f3f22"
TWEAKS = [
  {
    "ChatOpenAI-cU2gL": {},
    "LLMChain-54NC9": {},
    "PromptTemplate-v7kpt": {},
    "ConversationBufferMemory-ZyEB8": {},
    "AgentInitializer-LaYvH": {},
    "Search-4Itds": {}
  }
]

def run_flow(message: str, flow_id: str = FLOW_ID, tweaks: dict = TWEAKS) -> dict:
    api_url = f"{BASE_API_URL}/{flow_id}"
    payload = {"inputs": {"input": message}}
    if tweaks:
        payload["tweaks"] = tweaks
    response = requests.post(api_url, json=payload)
    return response.json()

# User interface for chat
st.title("Chat with LangFlow")
message = st.text_input("Enter your message:")
send_button = st.button("Send")

# Send the message when the send button is pressed
if send_button:
    response = run_flow(message)
    st.write(f"Response: {response}")
